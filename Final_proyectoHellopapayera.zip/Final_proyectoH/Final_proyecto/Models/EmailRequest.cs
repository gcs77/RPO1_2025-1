﻿namespace Final_proyecto.Models
{
    public class EmailRequest
    {
        public string Email { get; set; }
    }
}
