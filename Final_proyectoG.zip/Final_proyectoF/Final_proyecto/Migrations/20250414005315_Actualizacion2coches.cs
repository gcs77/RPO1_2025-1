﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Final_proyecto.Migrations
{
    /// <inheritdoc />
    public partial class Actualizacion2coches : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ImagenUrl",
                table: "Coches",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<decimal>(
                name: "Precio",
                table: "Coches",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ImagenUrl",
                table: "Coches");

            migrationBuilder.DropColumn(
                name: "Precio",
                table: "Coches");
        }
    }
}
