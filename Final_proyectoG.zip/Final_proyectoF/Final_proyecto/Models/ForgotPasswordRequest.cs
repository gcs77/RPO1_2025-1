﻿namespace Final_proyecto.Models
{
    public class ForgotPasswordRequest
    {
        public string Email { get; set; }
    }
}
