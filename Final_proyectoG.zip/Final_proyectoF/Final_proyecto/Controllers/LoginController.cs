﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Text;
using Final_proyecto.Data;
using Microsoft.EntityFrameworkCore;
using Final_proyecto.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System;
using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace Final_proyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public LoginController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Final_proyecto.Models.LoginRequest request)
        {
            var usuario = await _context.Clientes
                .FirstOrDefaultAsync(c => c.Email == request.email);

            if (usuario == null || usuario.Contraseña != request.contrasena)
                return Unauthorized("Credenciales incorrectas");

            var token = GenerarToken(usuario.Email, usuario.Rol);

            return Ok(new { token });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Final_proyecto.Models.RegisterRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Contraseña))
                return BadRequest("Email y contraseña son requeridos");

            if (await _context.Clientes.AnyAsync(c => c.Email == request.Email))
                return BadRequest("El correo ya está registrado");

            var nuevoCliente = new Clientes
            {
                Email = request.Email,
                Contraseña = request.Contraseña,
                Rol = "Comprador" // Siempre será comprador
            };

            _context.Clientes.Add(nuevoCliente);
            await _context.SaveChangesAsync();

            return Ok("Cuenta creada con éxito");
        }

        private string GenerarToken(string email, string rol)
        {
            var key = Encoding.ASCII.GetBytes("clave_super_secreta_para_el_token");

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, email),
                    new Claim(ClaimTypes.Role, rol)
                }),
                Expires = DateTime.UtcNow.AddHours(1), // El token expira en 1 hora
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        // Acción para olvido de contraseña
        [HttpPost("forgotpassword")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequest request)
        {
            var usuario = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == request.Email);

            if (usuario == null)
                return BadRequest("No existe una cuenta registrada con ese correo");

            // Generamos un token de restablecimiento de contraseña único
            var tokenRestablecer = Guid.NewGuid().ToString();
            var fechaExpiracion = DateTime.UtcNow.AddHours(1); // Token válido por 1 hora

            // Guardamos el token y la fecha de expiración en la base de datos
            usuario.PasswordResetToken = tokenRestablecer;
            usuario.PasswordResetTokenExpiration = fechaExpiracion;
            await _context.SaveChangesAsync();

            // Generar el link de restablecimiento
            var linkRestablecer = Url.Action("ResetPassword", "Login", new { token = tokenRestablecer }, Request.Scheme);

            // Enviar el correo con el enlace de restablecimiento
            EnviarCorreoRestablecer(usuario.Email, linkRestablecer);

            return Ok("Se ha enviado un enlace para restablecer la contraseña a tu correo");
        }

        // Método para enviar correo con el enlace de restablecimiento
        private void EnviarCorreoRestablecer(string email, string linkRestablecer)
        {
            var correo = _configuration["EmailSettings:SenderEmail"];
            var contrasena = _configuration["EmailSettings:SenderPassword"];
            var smtpHost = _configuration["EmailSettings:SmtpHost"];
            var smtpPort = _configuration["EmailSettings:SmtpPort"];

            var mensaje = new MailMessage
            {
                From = new MailAddress(correo),
                Subject = "Restablecer tu contraseña",
                Body = $"Haga clic en el siguiente enlace para restablecer su contraseña: <a href=\"{linkRestablecer}\">Restablecer contraseña</a>",
                IsBodyHtml = true
            };

            mensaje.To.Add(email);

            var clienteSmtp = new SmtpClient(smtpHost)
            {
                Port = int.Parse(smtpPort),
                Credentials = new NetworkCredential(correo, contrasena),
                EnableSsl = true
            };

            clienteSmtp.Send(mensaje);
        }

        // Acción para mostrar la vista de restablecimiento de contraseña
        [HttpGet("resetpassword")]
        public async Task<IActionResult> ResetPassword(string token)
        {
            if (string.IsNullOrEmpty(token))
                return BadRequest("Token inválido.");

            var usuario = await _context.Clientes.FirstOrDefaultAsync(c => c.PasswordResetToken == token && c.PasswordResetTokenExpiration > DateTime.UtcNow);

            if (usuario == null)
                return BadRequest("Este enlace de restablecimiento ha expirado o no es válido.");

            ViewBag.Token = token;
            return View(); // Mostramos la vista para cambiar la contraseña
        }

        // Acción para actualizar la contraseña después de que el usuario envíe el nuevo valor
        [HttpPost("resetpassword")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest request)
        {
            var usuario = await _context.Clientes.FirstOrDefaultAsync(c => c.PasswordResetToken == request.Token && c.PasswordResetTokenExpiration > DateTime.UtcNow);

            if (usuario == null)
                return BadRequest("Este enlace de restablecimiento ha expirado o no es válido.");

            // Actualizamos la contraseña
            usuario.Contraseña = request.NuevaContraseña;
            usuario.PasswordResetToken = null; // Limpiamos el token después de usarlo
            usuario.PasswordResetTokenExpiration = null;
            await _context.SaveChangesAsync();

            return Ok("Contraseña actualizada exitosamente.");
        }
    }

    // Clases auxiliares
    public class ForgotPasswordRequest
    {
        public string Email { get; set; }
    }

    public class ResetPasswordRequest
    {
        public string Token { get; set; }
        public string NuevaContraseña { get; set; }
    }
}
