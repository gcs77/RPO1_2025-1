﻿namespace Final_proyecto.Models
{
    public class Coches
    {
        
        
            public int Id { get; set; }
            public string Marca { get; set; }
            public string Modelo { get; set; }
            public int Año { get; set; }
            public string Color { get; set; }
            public int Npuertas { get; set; }
        // Otras propiedades  
        public decimal Precio { get; set; }
        public string ImagenUrl { get; set; }

    }
}
