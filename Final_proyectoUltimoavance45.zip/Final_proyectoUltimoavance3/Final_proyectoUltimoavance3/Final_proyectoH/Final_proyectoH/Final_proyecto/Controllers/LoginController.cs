﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Final_proyecto.Data;
using Final_proyecto.Models;

namespace Final_proyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly EmailService _emailService;

        public static Dictionary<string, string> codigosVerificacion = new Dictionary<string, string>();

        public LoginController(ApplicationDbContext context, EmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var usuario = await _context.Clientes
                .FirstOrDefaultAsync(c => c.Email == request.email);

            if (usuario == null || usuario.Contraseña != request.contrasena)
                return Unauthorized("Credenciales incorrectas");

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, usuario.Email),
                new Claim(ClaimTypes.Role, usuario.Rol)
            };

            var claimsIdentity = new ClaimsIdentity(
                claims, CookieAuthenticationDefaults.AuthenticationScheme);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity));

            return Ok(new { message = "Inicio de sesión exitoso" });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Contraseña))
                return BadRequest("Email y contraseña son requeridos");

            if (!codigosVerificacion.TryGetValue(request.Email, out var codigoGuardado) || request.CodigoVerificacion != codigoGuardado)
                return BadRequest("Código de verificación incorrecto o no proporcionado");

            if (await _context.Clientes.AnyAsync(c => c.Email == request.Email))
                return BadRequest("El correo ya está registrado");

            var nuevoCliente = new Clientes
            {
                Email = request.Email,
                Contraseña = request.Contraseña,
                Rol = "Comprador"
            };

            _context.Clientes.Add(nuevoCliente);
            await _context.SaveChangesAsync();

            codigosVerificacion.Remove(request.Email);

            return Ok("Cuenta creada con éxito");
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.NewPassword))
                return BadRequest("Email y nueva contraseña son requeridos");

            if (!codigosVerificacion.TryGetValue(request.Email, out var codigoGuardado) || request.CodigoVerificacion != codigoGuardado)
                return BadRequest("Código de verificación incorrecto o no proporcionado");

            var usuario = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == request.Email);

            if (usuario == null)
                return NotFound("Usuario no encontrado");

            usuario.Contraseña = request.NewPassword;
            await _context.SaveChangesAsync();

            codigosVerificacion.Remove(request.Email);

            return Ok("Contraseña actualizada exitosamente");
        }

        [HttpPost("enviar-codigo")]
        public async Task<IActionResult> EnviarCodigoVerificacion([FromBody] EmailRequest request)
        {
            var email = request.Email;

            if (string.IsNullOrWhiteSpace(email))
                return BadRequest("El email es requerido");

            var codigo = new Random().Next(100000, 999999).ToString();

            codigosVerificacion[email] = codigo;

            string asunto = "Código de verificación";
            string cuerpo = $"<h2>Tu código es: {codigo}</h2>";

            await _emailService.SendEmailAsync(email, asunto, cuerpo);

            return Ok("Código enviado");
        }
    }
}
