﻿namespace Final_proyecto.Models
{
    public class VerificationRequest
    {
        public string Email { get; set; }
        public string Codigo { get; set; }
    }
}
