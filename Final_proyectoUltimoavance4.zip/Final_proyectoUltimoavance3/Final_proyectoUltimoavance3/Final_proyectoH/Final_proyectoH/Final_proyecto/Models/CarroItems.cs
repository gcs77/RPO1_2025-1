﻿namespace Final_proyecto.Models
{
    public class CarroItems
    {
        public int Id { get; set; }
        public int ClienteId { get; set; }
        public Clientes Cliente { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public decimal Precio { get; set; }
        public string ImagenUrl { get; set; }
        public int Cantidad { get; set; }
    }
}
