﻿using Microsoft.EntityFrameworkCore;
using Final_proyecto.Models;

namespace Final_proyecto.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Clientes> Clientes { get; set; }
        public DbSet<Coches> Coches { get; set; }
        public DbSet<CarroItems> CarroItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configurar la relación entre CarroItem y Cliente
            modelBuilder.Entity<CarroItems>()
                .HasOne(ci => ci.Cliente)
                .WithMany()
                .HasForeignKey(ci => ci.ClienteId);
        }
    }
}
